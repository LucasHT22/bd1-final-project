<?php
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../Book.php';

class BookDAO {
    private $pdo;
    public function __construct() {
        $this->pdo = Database::connect();
    }

    public function findAll() {
        $stmt = $this->pdo->query("SELECT * FROM books");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findById($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM books WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function save($title, $author, $year) {
        $stmt = $this->pdo->prepare("INSERT INTO books (title, author, year, available) VALUES (:title, :author, :year, true)");
        $stmt->bindValue(':title', $title, PDO::PARAM_STR);
        $stmt->bindValue(':author', $author, PDO::PARAM_STR);
        $stmt->bindValue(':year', $year, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function update($id, $title, $author, $year) {
        $stmt = $this->pdo->prepare("UPDATE books SET title = :title, author = :author, year = :year WHERE id = :id");
        $stmt->bindValue(':title', $title, PDO::PARAM_STR);
        $stmt->bindValue(':author', $author, PDO::PARAM_STR);
        $stmt->bindValue(':year', $year, PDO::PARAM_INT);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function delete($id) {
        $stmt = $this->pdo->prepare("DELETE FROM books WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}
