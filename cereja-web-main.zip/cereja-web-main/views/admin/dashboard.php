<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Cereja Admin</title>
</head>
<body>
<style>
        * {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #a4003d;
            color: #ffa5a5;
        }

        div.main {
            margin: 5%;
        }
        a, button, input {
            background-color: #ffa5a5;
            color: #a4003d;
            border-radius: 25px;
            padding: 25px;
            text-decoration: none;
            font-weight: bold;
            margin: 5px;
            width: 120px;
            border: 1px solid #ffa5a5;
        }
        h1 {
            color: #f5cdcd;
            font-size: 50px;
        }
        a:hover, button:hover {
            background-color: #a4003d;
            color: #f5cdcd;
            border-radius: 25px;
            padding: 25px;
            text-decoration: none;
            border: 1px solid #a4003d;
        }
        div.buttons {
            display: flex;
            flex-wrap: wrap;
        }
        div#inputs {
            display: flex;
            flex-wrap: wrap;
        }
    </style>
<div class="main">
<h1>Welcome, Admin <?= htmlspecialchars($_SESSION['user']['name']) ?></h1>
<div id="buttons">
    <a href="../login.php">Logout</a>
    <a href="books.php">Manage Books</a>
    <a href="users.php">Manage Users</a>
    <a href="rentals.php">View Rentals</a>
</div>
</div>
</body>
</html>