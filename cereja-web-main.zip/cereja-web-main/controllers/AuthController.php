<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../models/dao/UserDAO.php';

class AuthController {
    
    public static function login($email, $password) {
        try {
            $dao = new UserDAO();
            $user = $dao->findByEmail($email);

            if ($user && $password === $user->getPassword()) {
                $_SESSION['user'] = [
                    'id' => $user->getId(),
                    'name' => $user->getName(),
                    'email' => $user->getEmail(),
                    'role' => $user->getRole()
                ];

                if ($user->getRole() === 'admin') {
                    header("Location: ../views/admin/dashboard.php");
                } else {
                    header("Location: ../views/client/dashboard.php");
                }
            exit;
        } else {
            echo "Invalid login";
        }
    } catch (Exception $e) {
        echo "An error occurred: " . $e->getMessage();
    }
}

    public static function logout() {
        $_SESSION = array();
        
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        
        session_destroy();
        
        $_SESSION['success_message'] = 'Logout done.';
        header("Location: ../login.php");
        exit();
    }
    
    public static function checkAuth($requiredRole = null) {
        if (!isset($_SESSION['user'])) {
            header("Location: ../login.php");
            exit();
        }
        
        if ($requiredRole && $_SESSION['user']['role'] !== $requiredRole) {
            $_SESSION['error_message'] = 'Not allowed.';
            header("Location: ../login.php");
            exit();
        }
        
        return $_SESSION['user'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["login"])) {
    if (empty($_POST['email']) || empty($_POST['password'])) {
        $_SESSION['error_message'] = 'Email and password required.';
        header("Location: ../login.php");
        exit();
    }
    
    AuthController::login($_POST['email'], $_POST['password']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['logout'])) {
    AuthController::logout();
}

header("Location: ../login.php");
exit();
?>