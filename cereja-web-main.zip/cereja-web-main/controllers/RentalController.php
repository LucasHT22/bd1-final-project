<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../models/dao/RentalDAO.php';
$dao = new RentalDAO();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create'])) {
    $user_id = $_SESSION['user']['id'];
    $book_id = $_POST['book_id'] ?? null;
    $rental_date = $_POST['rental_date'] ?? '';
    $return_date = $_POST['return_date'] ?? '';

    if ($user_id && $book_id && $rental_date && $return_date) {
        $dao->registerRental($user_id, $book_id, $rental_date, $return_date);
    }

    if ($_SESSION['user']['role'] === 'admin') {
        header("Location: ../views/admin/rentals.php");
    } else {
        header("Location: ../views/client/dashboard.php");
    }
}

if (isset($_GET['delete'])) {
    $dao->delete($_GET['delete']);
    header("Location: ../views/admin/rentals.php");
    exit;
}
