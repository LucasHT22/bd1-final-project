<?php 
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../Rental.php';

class RentalDAO {
    private $pdo;
    public function __construct() {
        $this->pdo = Database::connect();
    }

    public function findByUserId($user_id) {
        $stmt = $this->pdo->prepare("SELECT r.*, b.title FROM rentals r JOIN books b ON r.book_id = b.id WHERE r.user_id = :user_id");
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }    

    public function registerRental($user_id, $book_id, $rental_date, $return_date) {
        $stmt = $this->pdo->prepare("INSERT INTO rentals (user_id, book_id, rental_date, return_date) VALUES (:user_id, :book_id, :rental_date, :return_date)");
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindValue(':book_id', $book_id, PDO::PARAM_INT);
        $stmt->bindValue(':rental_date', $rental_date, PDO::PARAM_STR);
        $stmt->bindValue(':return_date', $return_date, PDO::PARAM_STR);
        return $stmt->execute();
    }

    public function findAll() {
        $stmt = $this->pdo->query("SELECT r.*, u.name as user, b.title as book FROM rentals r JOIN users u ON r.user_id = u.id JOIN books b ON r.book_id = b.id");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function delete($id) {
        $stmt = $this->pdo->prepare("DELETE FROM rentals WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}
