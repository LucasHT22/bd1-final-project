<?php
class Rental {
    private $id;
    private $user_id;
    private $book_id;
    private $rental_date;
    private $return_date;

    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getUserId() { return $this->user_id; }
    public function setUserId($user_id) { $this->user_id = $user_id; }

    public function getBookId() { return $this->book_id; }
    public function setBookId($book_id) { $this->book_id = $book_id; }

    public function getRentalDate() { return $this->rental_date; }
    public function setRentalDate($rental_date) { $this->rental_date = $rental_date; }

    public function getReturnDate() { return $this->return_date; }
    public function setReturnDate($return_date) { $this->return_date = $return_date; }
}