<?php
class Database {
    public static function connect() {
        $host = 'localhost';
        $db = 'cereja-web';
        $user = 'postgres';
        $pass = '2202';
        $port = '5432';
        return new PDO("pgsql:host=$host;port=$port;dbname=$db", $user, $pass);
    }
}
