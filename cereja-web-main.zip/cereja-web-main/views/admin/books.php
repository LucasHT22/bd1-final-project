<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

require_once __DIR__ . '/../../models/dao/BookDAO.php';
$dao = new BookDAO();
$books = $dao->findAll();

$editBook = null;
if (isset($_GET['edit'])) {
    $editBook = $dao->findById($_GET['edit']);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Books - Cereja Admin</title>
</head>
<body>
<style>
        * {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #a4003d;
            color: #ffa5a5;
        }

        div.main {
            margin: 5%;
        }
        a, button, input {
            background-color: #ffa5a5;
            color: #a4003d;
            border-radius: 25px;
            padding: 25px;
            text-decoration: none;
            font-weight: bold;
            margin: 5px;
            width: 120px;
            border: 1px solid #ffa5a5;
        }
        a.compact {
            background-color: #ffa5a5;
            color: #a4003d;
            border-radius: 5px;
            padding: 5px;
            text-decoration: none;
            font-weight: bold;
            margin: 5px;
            width: 120px;
            border: 1px solid #ffa5a5;
        }
        a.compact:hover {
            background-color: #a4003d;
            color: #f5cdcd;
            border-radius: 5px;
            padding: 5px;
            text-decoration: none;
            border: 1px solid #a4003d;
        }
        h1 {
            color: #f5cdcd;
            font-size: 50px;
        }
        a:hover, button:hover {
            background-color: #a4003d;
            color: #f5cdcd;
            border-radius: 25px;
            padding: 25px;
            text-decoration: none;
            border: 1px solid #a4003d;
        }
        div.buttons {
            display: flex;
            flex-wrap: wrap;
        }
        div#inputs {
            display: flex;
            flex-wrap: wrap;
        }
        li {
            margin-top: 15px;
        }
    </style>
    <div class="main">
        <h1>Books</h1>

        <h2><?= $editBook ? 'Edit Book' : 'Add New Book' ?></h2>
        <form method="post" action="../../controllers/BookController.php">
            <input type="hidden" name="id" value="<?= $editBook['id'] ?? '' ?>">
            <input type="text" name="title" placeholder="Title" value="<?= htmlspecialchars($editBook['title'] ?? '') ?>" required>
            <input type="text" name="author" placeholder="Author" value="<?= htmlspecialchars($editBook['author'] ?? '') ?>" required>
            <input type="number" name="year" placeholder="Year" value="<?= htmlspecialchars($editBook['year'] ?? '') ?>" required>
            <button type="submit">Save</button>
            <?php if ($editBook): ?>
                <a href="books.php">Cancel</a>
            <?php endif; ?>
        </form>

        <h2>Books List</h2>
        <ul>
            <?php foreach ($books as $book): ?>
                <li>
                    <?= htmlspecialchars($book['title']) ?> by <?= htmlspecialchars($book['author']) ?> (<?= $book['year'] ?>)
                    <a class="compact" href="books.php?edit=<?= $book['id'] ?>">Edit</a>
                    <a class="compact" href="../../controllers/BookController.php?delete=<?= $book['id'] ?>" onclick="return confirm('Delete this book?')">Delete</a>
                </li>
            <?php endforeach; ?>
        </ul>

        <br />
        <br />
        <br />
        <a href="../admin/dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>