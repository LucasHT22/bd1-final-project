<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cereja - The cherry on top</title>
</head>
<body>
<style>
        * {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #a4003d;
            color: #ffa5a5;
        }

        div.main {
            margin: 5%;
        }
        a, button, input {
            background-color: #ffa5a5;
            color: #a4003d;
            border-radius: 25px;
            padding: 25px;
            text-decoration: none;
            font-weight: bold;
            margin: 5px;
            width: 120px;
            border: 1px solid #ffa5a5;
        }
        h1 {
            color: #f5cdcd;
            font-size: 200px;
        }
        a:hover, button:hover {
            background-color: #a4003d;
            color: #f5cdcd;
            border-radius: 25px;
            padding: 25px;
            text-decoration: none;
            border: 1px solid #a4003d;
        }
        div.buttons {
            display: flex;
            flex-wrap: wrap;
        }
        div#inputs {
            display: flex;
            flex-wrap: wrap;
        }
    </style>
    <div class="main">
        <div id="main-text">
            <h1>Cereja</h1>
            <p>The missing cherry on top of your library.</p>
        </div>
        <form method="post" action="?path=auth">
            <div id="inputs">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <div id="buttons"></div>
            <button type="submit" name="login">Login</button>
        </form>
    </div>
</body>
</html>