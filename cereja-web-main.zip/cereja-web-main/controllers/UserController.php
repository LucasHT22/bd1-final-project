<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../models/dao/UserDAO.php';
$dao = new UserDAO();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    $id = $_POST['id'] ?? null;
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? null;
    $role = $_POST['role'] ?? 'client';

    if ($id) {
        $dao->update($id, $name, $email, $password, $role);
    } else {
        $dao->save($name, $email, $password, $role);
    }

    header("Location: ../views/admin/users.php");
    exit;
}

if (isset($_GET['delete'])) {
    $dao->delete($_GET['delete']);
    header("Location: ../views/admin/users.php");
    exit;
}
