<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../models/dao/BookDAO.php';
$dao = new BookDAO();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $title = $_POST['title'] ?? '';
    $author = $_POST['author'] ?? '';
    $year = $_POST['year'] ?? null;

    if ($id) {
        $dao->update($id, $title, $author, $year);
    } else {
        $dao->save($title, $author, $year);
    }

    header("Location: ../views/admin/books.php");
    exit;
}

if (isset($_GET['delete'])) {
    $dao->delete($_GET['delete']);
    header("Location: ../views/admin/books.php");
    exit;
}
