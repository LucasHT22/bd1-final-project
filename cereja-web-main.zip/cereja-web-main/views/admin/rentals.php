<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

require_once __DIR__ . '/../../models/dao/RentalDAO.php';
$dao = new RentalDAO();
$rentals = $dao->findAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Rentals - Cereja Admin</title>
</head>
<body>
    <style>
        * {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #a4003d;
            color: #ffa5a5;
        }

        div.main {
            margin: 5%;
        }
        a, button, input {
            background-color: #ffa5a5;
            color: #a4003d;
            border-radius: 25px;
            padding: 25px;
            text-decoration: none;
            font-weight: bold;
            margin: 5px;
            width: 120px;
            border: 1px solid #ffa5a5;
        }
        a.compact {
            background-color: #ffa5a5;
            color: #a4003d;
            border-radius: 5px;
            padding: 5px;
            text-decoration: none;
            font-weight: bold;
            margin: 5px;
            width: 120px;
            border: 1px solid #ffa5a5;
        }
        a.compact:hover {
            background-color: #a4003d;
            color: #f5cdcd;
            border-radius: 5px;
            padding: 5px;
            text-decoration: none;
            border: 1px solid #a4003d;
        }
        h1 {
            color: #f5cdcd;
            font-size: 50px;
        }
        a:hover, button:hover {
            background-color: #a4003d;
            color: #f5cdcd;
            border-radius: 25px;
            padding: 25px;
            text-decoration: none;
            border: 1px solid #a4003d;
        }
        div.buttons {
            display: flex;
            flex-wrap: wrap;
        }
        div#inputs {
            display: flex;
            flex-wrap: wrap;
        }
        li {
            margin-top: 15px;
        }
    </style>

    <div class="main">
    <h1>Rentals</h1>

    <h2>New Rental</h2>
    <form method="post" action="../../controllers/RentalController.php">
        <input type="number" name="user_id" placeholder="User ID" required>
        <input type="number" name="book_id" placeholder="Book ID" required>
        <label>Rental Date: <input type="date" name="rental_date" required></label>
        <label>Return Date: <input type="date" name="return_date" required></label>
        <button type="submit" name="create">Create Rental</button>
    </form>

    <h2>Rental List</h2>
    <ul>
        <?php foreach ($rentals as $rental): ?>
            <li>
                <?= htmlspecialchars($rental['user']) ?> rented "<?= htmlspecialchars($rental['book']) ?>" 
                from <?= $rental['rental_date'] ?> to <?= $rental['return_date'] ?>
                <a class="compact" href="../../controllers/RentalController.php?delete=<?= $rental['id'] ?>" onclick="return confirm('Delete this rental?')">Delete</a>
            </li>
        <?php endforeach; ?>
    </ul>
    
    <br />
    <br />
    <br />
    <a href="../admin/dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
