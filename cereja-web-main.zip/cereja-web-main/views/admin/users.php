<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

require_once __DIR__ . '/../../models/dao/UserDAO.php';
$dao = new UserDAO();
$users = $dao->findAll();

$editUser = null;
if (isset($_GET['edit'])) {
    $editUser = $dao->findById($_GET['edit']);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Users - Cereja Admin</title>
</head>
<body>
<style>
        * {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #a4003d;
            color: #ffa5a5;
        }

        div.main {
            margin: 5%;
        }
        a, button, input, select, option {
            background-color: #ffa5a5;
            color: #a4003d;
            border-radius: 25px;
            padding: 25px;
            text-decoration: none;
            font-weight: bold;
            margin: 5px;
            width: 120px;
            border: 1px solid #ffa5a5;
        }
        a.compact {
            background-color: #ffa5a5;
            color: #a4003d;
            border-radius: 5px;
            padding: 5px;
            text-decoration: none;
            font-weight: bold;
            margin: 5px;
            width: 120px;
            border: 1px solid #ffa5a5;
        }
        a.compact:hover {
            background-color: #a4003d;
            color: #f5cdcd;
            border-radius: 5px;
            padding: 5px;
            text-decoration: none;
            border: 1px solid #a4003d;
        }
        h1 {
            color: #f5cdcd;
            font-size: 50px;
        }
        a:hover, button:hover {
            background-color: #a4003d;
            color: #f5cdcd;
            border-radius: 25px;
            padding: 25px;
            text-decoration: none;
            border: 1px solid #a4003d;
        }
        div.buttons {
            display: flex;
            flex-wrap: wrap;
        }
        div#inputs {
            display: flex;
            flex-wrap: wrap;
        }
        li {
            margin-top: 15px;
        }
    </style>
    <h1>Users</h1>

    <h2><?= $editUser ? 'Edit User' : 'Add New User' ?></h2>
    <form method="post" action="../../controllers/UserController.php">
        <input type="hidden" name="id" value="<?= $editUser['id'] ?? '' ?>">
        <input type="text" name="name" placeholder="Name" value="<?= htmlspecialchars($editUser['name'] ?? '') ?>" required>
        <input type="email" name="email" placeholder="Email" value="<?= htmlspecialchars($editUser['email'] ?? '') ?>" required>
        <input type="password" name="password" placeholder="Password" <?= $editUser ? '' : 'required' ?>>
        <select name="role">
            <option value="client" <?= ($editUser['role'] ?? '') === 'client' ? 'selected' : '' ?>>Client</option>
            <option value="admin" <?= ($editUser['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Admin</option>
        </select>
        <button type="submit" name="save">Save</button>
        <?php if ($editUser): ?>
            <a href="users.php">Cancel</a>
        <?php endif; ?>
    </form>

    <h2>User List</h2>
    <ul>
        <?php foreach ($users as $user): ?>
            <li>
                <?= htmlspecialchars($user['name']) ?> (<?= htmlspecialchars($user['email']) ?>) - <?= $user['role'] ?>
                <a class="compact" href="users.php?edit=<?= $user['id'] ?>">Edit</a>
                <a class="compact" href="../../controllers/UserController.php?delete=<?= $user['id'] ?>" onclick="return confirm('Delete this user?')">Delete</a>
            </li>
        <?php endforeach; ?>
    </ul>

    <br />
    <br />
    <br />
    <a href="../admin/dashboard.php">Back to Dashboard</a>
</body>
</html>