<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$path = $_GET['path'] ?? 'login';

$baseViewPath = realpath(__DIR__ . '/../views') . DIRECTORY_SEPARATOR;

switch ($path) {
    case 'login':
        require $baseViewPath . 'login.php';
        break;
        
    case 'admin/dashboard':
        require $baseViewPath . 'admin/dashboard.php';
        break;

    case 'admin/books':
        require $baseViewPath . 'admin/books.php';
        break;

    case 'admin/rentals':
        require $baseViewPath . 'admin/rentals.php';
        break;

    case 'admin/users':
        require $baseViewPath . 'admin/users.php';
        break;

    case 'client/dashboard':
        require $baseViewPath . 'client/dashboard.php';
        break;

    case 'client/profile':
        require $baseViewPath . 'client/profile.php';
        break;

    case 'logout':
        session_destroy();
        header("Location: ?path=login");
        exit;

    case 'auth':
        require_once realpath(__DIR__ . '/../controllers/AuthController.php');
        break;

    
    default:
        http_response_code(404);
        echo "<h2>404 - Página não encontrada</h2>";
        break;
}
